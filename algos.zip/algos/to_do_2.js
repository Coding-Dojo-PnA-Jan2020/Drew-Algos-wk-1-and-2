//Reverse
//Given a numerical array, reverse the order of values, in-place.
function reverseArr(arr) {
    for (var i = 0; i < arr.length/2; i++) {
        var temp = arr[i];
        arr[i] = arr[arr.length-1-i];
        arr[arr.length-1-i] = temp;
    }
    return arr;
}
var arr1 = [1, 2, 3, 4, 5];
var arr2 = [1, 2, 3, 4, 5, 6];
console.log(reverseArr(arr1));
console.log(reverseArr(arr2));

//Rotate
//Implement rotateArr(arr, shiftBy) that accepts array and offset. Shift arr’s values to the right by that amount. 
//‘Wrap-around’ any values that shift off array’s end to the other side, so that no data is lost. Operate in-place: given ([1,2,3],1), change the array to [3,1,2].
function arrayRotate(arr, shiftBy) {
    var temp = arr[arr.length - 1];

    while (shiftBy > 0) {

        for (var i = arr.length - 1; i >= 0; i--) {
        arr[i] = arr[i - 1];
        }

        arr[0] = temp;
        temp = arr[arr.length - 1];
        shiftBy--;
    }
    console.log(arr);
    }
    var arr1 = [1, 2, 3];
    var shift1 = 1;
    arrayRotate(arr1, shift1);
    console.log("arrayRotate");

    //Filter Range
    //Given arr and values min and max, retain only the array values between min and max. 
    //Work in-place: return the array you are given, with values in original order. No built-in array functions.
    function arrayFilterRange(arr, min, max) {
    var temp;

    for(var i = 0; i < arr.length; i ++){
        if(arr[i] < min){

        }
    }
    console.log(arr);
    }
    var arr1 =  [1,2,3,4,5,6,7,8,9];
    var min1 = 2;
    var max1 = 8;
    arrayFilterRange(arr1, min1, max1);
    console.log("arrayFilterRange");

    //Concat
    //Create a standalone function that accepts two arrays. Return a new array containing the first array’s elements, followed by the second array’s elements.
    function arrayConcat(arr1, arr2) {
    var newArray = [];

    for(var i = 0; i < arr1.length; i ++){
        newArray[i] = arr1[i];
    }
    for(var i = 0; i < arr2.length; i++){
        newArray[i + arr1.length] = arr2[i];
    }
    console.log(newArray);
    }
    var arr1 = ["a","b"];
    var arr2 = [1,2];
    arrayConcat(arr1, arr2);
    console.log("arrayConcat");

    //Slyline Heights
    //Return array containing heights of buildings you can see, in order. 
    //Given [-1,1,1,7,3] return [1,7]. Given [0,4] return [4]. As always with challenges, do not use built-in array functions such as unshift().
    function arrayRemoveAt(arr, ind) {
    var temp = arr[ind];

    for (var i = ind; i < arr.length; i++) {
        arr[i] = arr[i + 1];
    }

    arr[arr.length - 1] = temp;
    return arr.pop();
    }

    function skylineHeights(arr) {
    var i = 0;
    var max = arr[0]

    while(i < arr.length) {
        console.log("i=" + i + " arr=" + arr);
        if(arr[i] <= 0) {
        arrayRemoveAt(arr, i);
        i--;
        }
        else if (arr[i] <= max) {
        arrayRemoveAt(arr, i);
        i--;
        }
        else if (arr[i] > max) {
        max = arr[i];
        }
        i++;
    }
    return arr;
    }
    console.log(skylineHeights([-1,1,1,7,3]));
    console.log(skylineHeights([0,4]));